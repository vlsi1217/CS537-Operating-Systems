// test program

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(void)
{
   float *p = 0;
   printf(1, "%x\n", *p);
   exit();
}
